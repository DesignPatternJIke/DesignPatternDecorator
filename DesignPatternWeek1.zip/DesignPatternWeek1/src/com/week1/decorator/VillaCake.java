package com.week1.decorator;

public interface VillaCake {
	double price();

}
